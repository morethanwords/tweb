function a(r,t){return Array.isArray(r)||(r=[r]),t?r.forEach(i=>i.setAttribute("disabled","true")):r.forEach(i=>i.removeAttribute("disabled")),()=>a(r,!t)}export{a as t};
//# sourceMappingURL=toggleDisability-6f5940d7.js.map
