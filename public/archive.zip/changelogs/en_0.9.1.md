• Added group members online counter.
• Added description of pinned message in its service notification.
• Improved profile avatar loading.
• Supported adding chats to privacy exceptions.
• Animated emoji starts to load when it's being typed.
• Fixed sending GIF images as media.
• Layout improvements.
