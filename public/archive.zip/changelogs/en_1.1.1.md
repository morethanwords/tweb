• Better Reactions: new look, bug fixes for Safari, improved animations.
• Auto-Download Settings became more detailed: you can now toggle auto-download by media type.
• Added ability to change playback rate of voice message and video.
• Video player bug fixes and improvements.
