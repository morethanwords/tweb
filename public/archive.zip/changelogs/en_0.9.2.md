• Flexible forwarding options: hide the sender name or media captions from messages.
• The ‘Choosing a Sticker’ user status now appears in chats and the chat list.
• Drag-and-drop or paste media to instantly attach it.
• 12-hour time formats are now supported.
• The author’s name will now appear when forwarding animated emoji.
• Fixed layout errors when choosing emoji.
• Fixed problems loading specific folders.
• Fixed layout errors when opening an empty contact.
• Fixed .GIF files that were displaying as documents.
• Fixed stickers that weren’t appearing in the suggestion window.
