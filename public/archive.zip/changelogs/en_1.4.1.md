• Supported Emoji 14.
• Improved connection stability.
• Files will now load faster with low-speed connection.
• Improved chat opening performance.
• Fixed flickering date.
• Fixed opening chat at wrong position.
