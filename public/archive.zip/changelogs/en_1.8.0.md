You can see the full list of new features and improvements here: https://t.me/WebK_en/11
