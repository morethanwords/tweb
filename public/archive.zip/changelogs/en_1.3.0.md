• Enjoy animated backgrounds: all-new fascinating gradient backgrounds featuring fluid transitions.
• Added menu for bots with beautiful bounce effect when expanding.
• Improvements for playback animation of voice messages.
