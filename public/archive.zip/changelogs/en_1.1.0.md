Reactions are now available:
• Open message menu to see all available reactions.
• Send a quick 👍 reaction by hovering the message.
• Set your quick reaction in settings.
• As admin, you are now able to control reactions in your groups or channels.
• You can see the list of people that sent reactions through message menu.
• Read receipts are now available; they are combined with reactions list when it's possible.
• You will receive notification when someone sends a reaction to your message.
