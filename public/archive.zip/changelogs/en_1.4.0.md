WebK introduced Video Chats back in December. 

And now we are proud to launch the first-ever version of Telegram P2P Calls on the Web – bringing native support for calls between two users, secured by end-to-end encryption.

Seamlessly call anyone, regardless of the app they are using – calls will work between the WebK app and any other stable Telegram app: Android, iOS, Desktop, and macOS. 

To call someone, open your chat with that user and click or tap the Phone icon in the top right corner. 

We mainly focused on calls in this update but also made important under-the-hood changes to the login flow, fixing rare issues when signing in.

In the coming weeks, the app will finally get support for all admin features in communities – bringing you dozens of new ways to manage groups and channels.
