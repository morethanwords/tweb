import { $rootScope, tsNow, copy } from "../utils";
import appMessagesIDsManager from "./appMessagesIDsManager";
import appChatsManager from "./appChatsManager";
import appPhotosManager from "./appPhotosManager";
import appUsersManager from "./appUsersManager";
import { RichTextProcessor } from "../richtextprocessor";
import appPeersManager from "./appPeersManager";
import apiUpdatesManager from "./apiUpdatesManager";
import AppStorage from '../storage';
import apiManager from "../mtproto/apiManager";

export class AppProfileManager {
  public botInfos: any = {};
  public usersFull: any = {};
  public chatsFull: any = {};
  public chatFullPromises: any = {};
  public chatParticipantsPromises: any = {};

  constructor() {
    $rootScope.$on('apiUpdate', (e: CustomEvent) => {
      let update = e.detail;
      // console.log('on apiUpdate', update)
      switch (update._) {
        case 'updateChatParticipants':
          var participants = update.participants;
          var chatFull = this.chatsFull[participants.id];
          if(chatFull !== undefined) {
            chatFull.participants = update.participants;
            $rootScope.$broadcast('chat_full_update', update.chat_id);
          }
          break;
  
        case 'updateChatParticipantAdd':
          var chatFull = this.chatsFull[update.chat_id];
          if (chatFull !== undefined) {
            var participants = chatFull.participants.participants || [];
            for(var i = 0, length = participants.length; i < length; i++) {
              if(participants[i].user_id == update.user_id) {
                return;
              }
            }
            participants.push({
              _: 'chatParticipant',
              user_id: update.user_id,
              inviter_id: update.inviter_id,
              date: tsNow(true)
            });
            chatFull.participants.version = update.version;
            $rootScope.$broadcast('chat_full_update', update.chat_id);
          }
          break
  
        case 'updateChatParticipantDelete':
          var chatFull = this.chatsFull[update.chat_id];
          if (chatFull !== undefined) {
            var participants = chatFull.participants.participants || [];
            for(var i = 0, length = participants.length; i < length; i++) {
              if(participants[i].user_id == update.user_id) {
                participants.splice(i, 1);
                chatFull.participants.version = update.version;
                $rootScope.$broadcast('chat_full_update', update.chat_id);
                return;
              }
            }
          }
          break
  
        case 'updateChannelPinnedMessage':
          var channelID = update.channel_id;
          var fullChannel = this.chatsFull[channelID];
          if (fullChannel !== undefined) {
            fullChannel.pinned_msg_id = appMessagesIDsManager.getFullMessageID(update.id, channelID);
            $rootScope.$broadcast('peer_pinned_message', -channelID);
          }
          break;
      }
    });
  
    $rootScope.$on('chat_update', (e: CustomEvent) => {
      let chatID = e.detail;
      var fullChat = this.chatsFull[chatID];
      var chat = appChatsManager.getChat(chatID);
      if(!chat.photo || !fullChat) {
        return;
      }
      var emptyPhoto = chat.photo._ == 'chatPhotoEmpty';
      //////console.log('chat_update:', fullChat);
      if(fullChat.chat_photo && emptyPhoto != (fullChat.chat_photo._ == 'photoEmpty')) {
        delete this.chatsFull[chatID];
        $rootScope.$broadcast('chat_full_update', chatID);
        return;
      }
      if(emptyPhoto) {
        return;
      }

      var smallUserpic = chat.photo.photo_small;
      var smallPhotoSize = appPhotosManager.choosePhotoSize(fullChat.chat_photo, 0, 0);
      if(JSON.stringify(smallUserpic) !== JSON.stringify(smallPhotoSize.location)) {
        delete this.chatsFull[chatID];
        $rootScope.$broadcast('chat_full_update', chatID);
      }
    });
  }

  public saveBotInfo(botInfo: any) {
    var botID = botInfo && botInfo.user_id
    if(!botID) {
      return false;
    }
    var commands: any = {};
    botInfo.commands.forEach((botCommand: any) => {
      commands[botCommand.command] = botCommand.description;
    })
    return this.botInfos[botID] = {
      id: botID,
      version: botInfo.version,
      shareText: botInfo.share_text,
      description: botInfo.description,
      commands: commands
    };
  }

  public getProfile(id: number, override?: any) {
    if(this.usersFull[id]) {
      return Promise.resolve(this.usersFull[id]);
    }

    return apiManager.invokeApi('users.getFullUser', {
      id: appUsersManager.getUserInput(id)
    }).then((userFull: any) => {
      if(override && override.phone_number) {
        userFull.user.phone = override.phone_number
        if(override.first_name || override.last_name) {
          userFull.user.first_name = override.first_name
          userFull.user.last_name = override.last_name
        }
        appUsersManager.saveApiUser(userFull.user);
      } else {
        appUsersManager.saveApiUser(userFull.user, true);
      }

      if(userFull.profile_photo) {
        appPhotosManager.savePhoto(userFull.profile_photo, {
          user_id: id
        });
      }

      if(userFull.about !== undefined) {
        userFull.rAbout = RichTextProcessor.wrapRichText(userFull.about, {noLinebreaks: true});
      }

      // NotificationsManager.savePeerSettings(id, userFull.notify_settings); // warning

      if(userFull.bot_info) {
        userFull.bot_info = this.saveBotInfo(userFull.bot_info);
      }

      return this.usersFull[id] = userFull;
    });
  }

  public getPeerBots(peerID: number) {
    var peerBots: any[] = [];
    if(peerID >= 0 && !appUsersManager.isBot(peerID) ||
      (appPeersManager.isChannel(peerID) && !appPeersManager.isMegagroup(peerID))) {
      return Promise.resolve(peerBots);
    }
    if(peerID >= 0) {
      return this.getProfile(peerID).then((userFull: any) => {
        var botInfo = userFull.bot_info;
        if(botInfo && botInfo._ != 'botInfoEmpty') {
          peerBots.push(botInfo);
        }
        return peerBots;
      });
    }

    return this.getChatFull(-peerID).then((chatFull: any) => {
      chatFull.bot_info.forEach((botInfo: any) => {
        peerBots.push(this.saveBotInfo(botInfo))
      });
      return peerBots;
    });
  }

  public getChatFull(id: number) {
    if(appChatsManager.isChannel(id)) {
      return this.getChannelFull(id);
    }
    if(this.chatsFull[id] !== undefined) {
      var chat = appChatsManager.getChat(id);
      if(chat.version == this.chatsFull[id].participants.version ||
        chat.pFlags.left) {
        return Promise.resolve(this.chatsFull[id]);
      }
    }
    if(this.chatFullPromises[id] !== undefined) {
      return this.chatFullPromises[id];
    }
    // console.trace(dT(), 'Get chat full', id, appChatsManager.getChat(id))
    return this.chatFullPromises[id] = apiManager.invokeApi('messages.getFullChat', {
      chat_id: appChatsManager.getChatInput(id)
    }).then((result: any) => {
      appChatsManager.saveApiChats(result.chats);
      appUsersManager.saveApiUsers(result.users);
      var fullChat = result.full_chat;
      if(fullChat && fullChat.chat_photo && fullChat.chat_photo.id) {
        appPhotosManager.savePhoto(fullChat.chat_photo);
      }
      /* NotificationsManager.savePeerSettings(-id, fullChat.notify_settings); */ // warning
      delete this.chatFullPromises[id];
      this.chatsFull[id] = fullChat;
      $rootScope.$broadcast('chat_full_update', id);

      return fullChat;
    });
  }

  public getChatInviteLink(id: number, force?: boolean) {
    return this.getChatFull(id).then((chatFull: any) => {
      if (!force &&
        chatFull.exported_invite &&
        chatFull.exported_invite._ == 'chatInviteExported') {
        return chatFull.exported_invite.link
      }
      var promise
      if (appChatsManager.isChannel(id)) {
        promise = apiManager.invokeApi('channels.exportInvite', {
          channel: appChatsManager.getChannelInput(id)
        })
      } else {
        promise = apiManager.invokeApi('messages.exportChatInvite', {
          chat_id: appChatsManager.getChatInput(id)
        })
      }
      return promise.then((exportedInvite: any) => {
        if(this.chatsFull[id] !== undefined) {
          this.chatsFull[id].exported_invite = exportedInvite;
        }
        return exportedInvite.link;
      });
    });
  }

  public getChannelParticipants(id: number, filter: any, limit: number, offset: number) {
    filter = filter || {_: 'channelParticipantsRecent'};
    limit = limit || 200;
    offset = offset || 0;
    var promiseKey = [id, filter._, offset, limit].join('_');
    var promiseData = this.chatParticipantsPromises[promiseKey];

    if(filter._ == 'channelParticipantsRecent') {
      var chat = appChatsManager.getChat(id);
      if(chat &&
          chat.pFlags && (
            chat.pFlags.kicked ||
            chat.pFlags.broadcast && !chat.pFlags.creator && !chat.admin_rights
          )) {
        return Promise.reject();
      }
    }

    var fetchParticipants = (cachedParticipants?: any[]) => {
      var hash = 0
      if (cachedParticipants) {
        var userIDs: number[] = [];
        cachedParticipants.forEach((participant: any) => {
          userIDs.push(participant.user_id);
        });
        userIDs.sort();
        userIDs.forEach((userID) => {
          hash = ((hash * 20261) + 0x80000000 + userID) % 0x80000000
        });
      }

      return apiManager.invokeApi('channels.getParticipants', {
        channel: appChatsManager.getChannelInput(id),
        filter: filter,
        offset: offset,
        limit: limit,
        hash: hash
      }).then((result: any) => {
        if(result._ == 'channels.channelParticipantsNotModified') {
          return cachedParticipants;
        }

        appUsersManager.saveApiUsers(result.users);
        return result.participants;
      })
    }

    var maybeAddSelf = (participants: any[]) => {
      var chat = appChatsManager.getChat(id);
      var selfMustBeFirst = filter._ == 'channelParticipantsRecent' &&
                            !offset &&
                            !chat.pFlags.kicked &&
                            !chat.pFlags.left

      if (selfMustBeFirst) {
        participants = copy(participants);
        var myID = appUsersManager.getSelf().id;
        var myIndex: any = false;
        var myParticipant;
        for(var i = 0, len = participants.length; i < len; i++) {
          if(participants[i].user_id == myID) {
            myIndex = i;
            break;
          }
        }
        if(myIndex !== false) {
          myParticipant = participants[i];
          participants.splice(i, 1);
        } else {
          myParticipant = {_: 'channelParticipantSelf', user_id: myID};
        }
        participants.unshift(myParticipant);
      }
      return participants;
    }

    var timeNow = tsNow();
    if(promiseData !== undefined) {
      var promise = promiseData[1];
      if(promiseData[0] > timeNow - 60000) {
        return promise;
      }
      let newPromise = promise.then((cachedParticipants: any) => {
        return fetchParticipants(cachedParticipants).then(maybeAddSelf)
      });
      this.chatParticipantsPromises[promiseKey] = [timeNow, newPromise];
      return newPromise;
    }

    var newPromise = fetchParticipants().then(maybeAddSelf);
    this.chatParticipantsPromises[promiseKey] = [timeNow, newPromise];
    return newPromise;
  }

  public getChannelFull(id: number, force?: boolean) {
    if(this.chatsFull[id] !== undefined && !force) {
      return Promise.resolve(this.chatsFull[id]);
    }
    if (this.chatFullPromises[id] !== undefined) {
      return this.chatFullPromises[id];
    }

    return this.chatFullPromises[id] = apiManager.invokeApi('channels.getFullChannel', {
      channel: appChatsManager.getChannelInput(id)
    }).then((result: any) => {
      appChatsManager.saveApiChats(result.chats);
      appUsersManager.saveApiUsers(result.users);
      var fullChannel = result.full_chat
      if (fullChannel && fullChannel.chat_photo.id) {
        appPhotosManager.savePhoto(fullChannel.chat_photo)
      }
      /* NotificationsManager.savePeerSettings(-id, fullChannel.notify_settings) */ // warning

      if(fullChannel.pinned_msg_id) {
        fullChannel.pinned_msg_id = appMessagesIDsManager.getFullMessageID(fullChannel.pinned_msg_id, id);
      }

      delete this.chatFullPromises[id];
      this.chatsFull[id] = fullChannel;
      $rootScope.$broadcast('chat_full_update', id);

      return fullChannel;
    }, (error) => {
      switch (error.type) {
        case 'CHANNEL_PRIVATE':
          var channel = appChatsManager.getChat(id);
          channel = {_: 'channelForbidden', access_hash: channel.access_hash, title: channel.title};
          apiUpdatesManager.processUpdateMessage({
            _: 'updates',
            updates: [{
              _: 'updateChannel',
              channel_id: id
            }],
            chats: [channel],
            users: []
          });
          break;
      }
      return Promise.reject(error);
    });
  }

  public invalidateChannelParticipants(id: number) {
    delete this.chatsFull[id];
    delete this.chatFullPromises[id];
    for(let key in this.chatParticipantsPromises) {
      //let val = this.chatParticipantsPromises[key];

      if(+key.split('_')[0] == id) {
        delete this.chatParticipantsPromises[key]
      }
    }

    $rootScope.$broadcast('chat_full_update', id);
  }

  public getChannelPinnedMessage(id: number) {
    return this.getChannelFull(id).then((fullChannel: any) => {
      var pinnedMessageID = fullChannel && fullChannel.pinned_msg_id
      if (!pinnedMessageID) {
        return false;
      }

      return AppStorage.get<number>('pinned_hidden' + id).then((hiddenMessageID: number) => {
        if(appMessagesIDsManager.getMessageLocalID(pinnedMessageID) == hiddenMessageID) {
          return false;
        }
        return pinnedMessageID;
      });
    });
  }

  public hideChannelPinnedMessage(id: number, pinnedMessageID: number) {
    var setKeys: any = {};
    setKeys['pinned_hidden' + id] = appMessagesIDsManager.getMessageLocalID(pinnedMessageID);
    AppStorage.set(setKeys);
    $rootScope.$broadcast('peer_pinned_message', -id);  
  }
}

export default new AppProfileManager();
