class AppSharedMediaManager {

}

export default new AppSharedMediaManager();
