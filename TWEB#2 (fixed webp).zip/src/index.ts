import './materialize.scss';
//import 'overlayscrollbars/css/OverlayScrollbars.min.css';
import './scss/style.scss';
import './scss/tgico.scss';
import { findUpClassName } from './lib/utils';

//import {appUsersManager} from './lib/services';

/* import pageIm from './components/pageIm';
import pageSignIn from './components/pageSignIn';
import { ripple } from './components/misc'; */
//import { getNearestDc } from './components/misc';

/* import registerServiceWorker from './registerServiceWorker';

registerServiceWorker(); */

//console.log('pineapples in my head');

/* Promise.all([
  import('./components/pageIm'),
  import('./components/pageSignIn'),
  import('./components/misc'),
  import('./lib/storage')
]).then(imports => {
  let [pageIm, pageSignIn, misc, AppStorage] = imports; */

  document.addEventListener('DOMContentLoaded', async() => {
    /* pageAuthCode({
      "_": "auth.sentCode",
      "pFlags": {},
      "flags": 6,
      "type": {
        "_": "auth.sentCodeTypeSms",
        "length": 5
      },
      "phone_code_hash": "98008787f0546e7419",	
      "next_type": {
        "_": "auth.codeTypeCall"
      },
      "timeout": 120,
      "phone_number": "+380509144504"
    }); */
  
    //let socket = new Socket(2);
  
    /* authorizer.auth(2).then((auth: any) => {
      console.log('authorized', auth);
    }, (error: any) => {
      console.log('Get networker error', error, error.stack);
      return Promise.reject(error);
      //return $q.reject(error);
    });
  
    return; */
  
    //pagePassword();
    let AppStorage = (await import('./lib/storage')).default;
  
    let auth = await AppStorage.get<any>('user_auth');

    let userID = auth.id || 0;
      
    if(!userID) {
      (await import('./components/pageSignIn')).default();
    } else {
      (await import('./components/pageIm')).default();
      //getNearestDc();
    }

    let misc = await import('./components/misc');
    Array.from(document.getElementsByClassName('rp')).forEach(misc.ripple);

    Array.from(document.body.getElementsByClassName('popup-close')).forEach(el => {
      let popup = findUpClassName(el, 'popup');
      el.addEventListener('click', () => {
        popup.classList.remove('active');
      });
    });

    //MTProto.apiFileManager.uploadFile(photo).then(function (inputFile) {
      //console.log('uploaded smthn', inputFile);
      /* MTProto.apiManager.invokeApi('photos.uploadProfilePhoto', {
        file: inputFile,
        caption: '',
        geo_point: {_: 'inputGeoPointEmpty'}
      }).then(function (updateResult) {
        AppUsersManager.saveApiUsers(updateResult.users)
        MtpApiManager.getUserID().then(function (id) {
          AppPhotosManager.savePhoto(updateResult.photo, {
            user_id: id
          })
          ApiUpdatesManager.processUpdateMessage({
            _: 'updateShort',
            update: {
              _: 'updateUserPhoto',
              user_id: id,
              date: tsNow(true),
              photo: AppUsersManager.getUser(id).photo,
              previous: true
            }
          })
          $scope.photo = {}
        })
      }) */
    //});
  });
//});


